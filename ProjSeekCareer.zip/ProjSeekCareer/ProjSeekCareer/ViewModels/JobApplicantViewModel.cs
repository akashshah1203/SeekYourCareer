﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using ProjSeekCareer.Models;

namespace ProjSeekCareer.ViewModels
{
    public class JobApplicantViewModel
    {
        public List<JobApplicant> JobApplicants { get; set; }
    }
}